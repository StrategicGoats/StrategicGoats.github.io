Welcome to the Beta for PERIL

The aim of this beta is to gather feedback on the current state 
of the game so we can improve it. We NEED your feedback!

If you want to submit feedback there is a link to a google form 
packaged with the game or you can email us at strategicgoats@outlook.com

Please read the instructions before playing and try to have fun.

Thank you for helping us make peril a better game.

- Strategic Goats